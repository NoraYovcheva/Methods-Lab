﻿using System;

namespace _03.Calculations
{
    class Program
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            string result = null;

            switch (command)
            {
                case "add":
                    result = Add(a, b);
                    break;
                case "subtract":
                    result = Subtract(a, b);
                    break;
                case "divide":
                    result = Divide(a, b);
                    break;
                case "multiply":
                    result = Multiply(a, b);
                    break;
                default:
                    break;
            }

            Console.WriteLine($"{result}");
        }

        static string Subtract(int a, int b)
        {
            int result = a - b;
            return $"{result}";
        }

        static string Divide(int a, int b)
        {
            int result = a / b;
            return $"{result}";
        }

        static string Multiply(int a, int b)
        {
            int result = a * b;
            return $"{result}";
        }

        static string Add(int a, int b)
        {
            int result = a + b;
            return $"{result}";
        }
    }
}
