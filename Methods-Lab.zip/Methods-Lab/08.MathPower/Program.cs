﻿using System;
using System.Linq;
using System.Text;

namespace _08.MathPower
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            int power = int.Parse(Console.ReadLine());

            double result = RiseToPower(number, power);

            Console.WriteLine(result);
        }

        static double RiseToPower(double number, int power) 
        {
            double result = 1;
            for (int i = 0; i < power; i++)
            {
                result *= number;
            }
            return result;
        }

        
    }
}
